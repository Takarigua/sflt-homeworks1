#!/bin/bash
WEB_SERVER_IP="localhost"
WEB_SERVER_PORT=80
FILE_PATH="/var/www/html/index.html"

# Проверка доступности порта
nc -z "$WEB_SERVER_IP" "$WEB_SERVER_PORT" > /dev/null 2>&1
PORT_STATUS=$?

# Проверка существования файла
if [ -f "$FILE_PATH" ]; then
    FILE_STATUS=0
else
    FILE_STATUS=1
fi

# Завершаем с кодом 0, если всё доступно, иначе 1
if [ "$PORT_STATUS" -eq 0 ] && [ "$FILE_STATUS" -eq 0 ]; then
    exit 0
else
    exit 1
fi

exit 0
